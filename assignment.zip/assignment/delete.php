<?php
require_once 'database.php';

if(isset($_POST['del']))
{

	$id=$_POST['del'];
	$conn = connection();
	$query="DELETE FROM `employee` WHERE id=$id";
	mysqli_query($conn,$query);
}


if(isset($_POST['update_id']))
{

	$id=$_POST['update_id'];
	$name=$_POST['update_name'];
	$date=$_POST['update_date'];
	$age=$_POST['update_age'];
	$email=$_POST['update_email'];
	
	$conn = connection();
	$query="UPDATE `employee` SET `Full_Name`='$name', `Date`=$date, `Age`=age, `Email`='$email' WHERE `id`=$id";
	mysqli_query($conn,$query);
}
?>