<?php

require_once('database.php');

add_record($_POST);


?>

