<?php
require_once 'database.php';
get_record();

?>