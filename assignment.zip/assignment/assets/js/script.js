$(function(){
	loadData();

});
$(function(){
	$('.form').on('submit',function(event){
		event.preventDefault();
		$form = $(this);
		//submission on server
		//validating the form
		if(validateForm($form)){
			reqst($form);

		}
		else{
			console.log('missing fields');

		}

	});

});
//getting id of the employee by clicking on the edit icon dynamically
$(function(){
	/*$('.table').on('click',function(event){
		event.preventDefault();
		var $anchor = $(event.target).parent('.icon');
		var id = $anchor.attr('data-id');
		console.log(id);
		if($anchor.hasClass('icon')){
			getRecord($anchor.attr('id'),id);
		}

	});*/

});
//function for getting data from the database

function getRecord(actionName, id){
	//var $modal ='';
	//var $form='';
	/*$.ajax({
		url:'getRecord.php',
		method: 'post',
		data: {id: id},
		success: function(response){
			//response = $.parseJSON(response);
			console.log(response);
			/*if(response.status == 'success'){
				if(actionName == 'updateEmp'){
					$modal = $('#updateEmp-modal')
					

				}
				else if(actionName == 'deleteEmp'){
					$modal = $('#deleteEmp-modal')

				}
				console.log($modal);

				//console.log($modal.find('.form').html());
				//$from = $modal.find('.form');
				//$form.find('.id').val( response.id);
				//$form.find('.fname').val( response.fname);
				//$form.find('.date').val( response.date);
				//$form.find('.age').val( response.age);
				//$form.find('.email').val( response.email);
				//$modal.modal('show');
			}

		}
	});*/
	


}



//function for operation
function reqst($form){
	$.ajax({
		//getting dynamic access of targetr page
		url: $form.attr('action'),
		method: $form.attr('method'),
		data: $form.serialize(),
		success: function(response){
			loadData();
			console.log(response);
		}

	});

}
//function for validating form
function validateForm($form){
	var inputList = $form.find('input');

	for(var i =0;i<inputList.length;i++){
		if(inputList[i].value=='' || inputList[i].value == null){
			return false;
		}
	}
	return true;

}

function loadData(){
	$.ajax({
		url:'read.php',
		method:'get',
		success: function(response){
			response = $.parseJSON(response);
			if(response.status == 'success'){
				$('.table').html(response.html);
			}
			console.log(response);

		}
	});
}

function del(id) {
	//alert(id);
	$.post("delete.php",
    {
        del: id
    },
    function(){
        loadData();
    }

    );
	// body...
}


function update(id,name,date,age,email) {
	//alert(id);
$('#u_id').val(id);
$('#u_fname').val(name);
$('#u_date').val(date);
$('#u_age').val(age);
$('#u_email').val(email);

$('#updateEmp').modal();
    	
}


function updateDATA() {
	//alert(id);
var id = $('#u_id').val();
var name= $('#u_fname').val();
var date = $('#u_date').val();
var age= $('#u_age').val();
var email = $('#u_email').val();

$.post("delete.php",
    {
        update_id: id,
        update_name: name,
        update_date: date,
        update_age: age,
        update_email: email

    },
    function(){
        loadData();
    }

    );

    	
}

function sortTable(n) {
  var table, rows, switching, i, x, y, shouldSwitch, dir, switchcount = 0;
  table = document.getElementById("myTable");
  switching = true;
  //Set the sorting direction to ascending:
  dir = "asc"; 
  /*Make a loop that will continue until
  no switching has been done:*/
  while (switching) {
    //start by saying: no switching is done:
    switching = false;
    rows = table.rows;
    /*Loop through all table rows (except the
    first, which contains table headers):*/
    for (i = 1; i < (rows.length - 1); i++) {
      //start by saying there should be no switching:
      shouldSwitch = false;
      /*Get the two elements you want to compare,
      one from current row and one from the next:*/
      x = rows[i].getElementsByTagName("TD")[n];
      y = rows[i + 1].getElementsByTagName("TD")[n];
      /*check if the two rows should switch place,
      based on the direction, asc or desc:*/
      if (dir == "asc") {
        if (x.innerHTML.toLowerCase() > y.innerHTML.toLowerCase()) {
          //if so, mark as a switch and break the loop:
          shouldSwitch= true;
          break;
        }
      } else if (dir == "desc") {
        if (x.innerHTML.toLowerCase() < y.innerHTML.toLowerCase()) {
          //if so, mark as a switch and break the loop:
          shouldSwitch = true;
          break;
        }
      }
    }
    if (shouldSwitch) {
      /*If a switch has been marked, make the switch
      and mark that a switch has been done:*/
      rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
      switching = true;
      //Each time a switch is done, increase this count by 1:
      switchcount ++;      
    } else {
      /*If no switching has been done AND the direction is "asc",
      set the direction to "desc" and run the while loop again.*/
      if (switchcount == 0 && dir == "asc") {
        dir = "desc";
        switching = true;
      }
    }
  }
}


function sortTablen() {
  var table, rows, switching, i, x, y, shouldSwitch;
  table = document.getElementById("myTable");
  switching = true;
  /*Make a loop that will continue until
  no switching has been done:*/
  while (switching) {
    //start by saying: no switching is done:
    switching = false;
    rows = table.rows;
    /*Loop through all table rows (except the
    first, which contains table headers):*/
    for (i = 1; i < (rows.length - 1); i++) {
      //start by saying there should be no switching:
      shouldSwitch = false;
      /*Get the two elements you want to compare,
      one from current row and one from the next:*/
      x = rows[i].getElementsByTagName("TD")[0];
      y = rows[i + 1].getElementsByTagName("TD")[0];
      //check if the two rows should switch place:
      if (Number(x.innerHTML) > Number(y.innerHTML)) {
        //if so, mark as a switch and break the loop:
        shouldSwitch = true;
        break;
      }
    }
    if (shouldSwitch) {
      /*If a switch has been marked, make the switch
      and mark that a switch has been done:*/
      rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
      switching = true;
    }
  }
}