<?php
require_once 'database.php';

if(isset($_GET['del']){
	echo 'hi';/*
	$id=$_GET['del'];
	$conn = connection();
	$query="DELETE FROM `employee` WHERE id=$id";
	mysqli_query($conn,$query);
	header('Location:index.php');*/
}

?>