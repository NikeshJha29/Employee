<?php
function connection(){
	$conn = mysqli_connect('localhost','root','','crud');
	if(!$conn){
		die('Connection can not established');
	}
	return $conn;
}


//function for retriving data from database

function get_record(){
	$conn = connection();

	$query = "SELECT * FROM `employee`";
	$result = mysqli_query($conn,$query);
	$html ='';
		//concating the string
		$html .='<thead>';
		$html .='<tr>';
		$html .="<th onclick='sortTablen()'>No</th>";
		$html .="<th onclick=\"sortTable(1)\">Full Name</th>";
		$html .="<th onclick=\"sortTable(2)\">Date Of Joining</th>";
		$html .="<th onclick=\"sortTable(3)\">Age</th>";
		$html .="<th onclick=\"sortTable(4)\">Email</th>";
		$html .='<th>Operation</th>';
		$html .='</tr>';
	    $html .='</thead>';
	if(mysqli_num_rows($result)){
		

		while($row = mysqli_fetch_assoc($result)){
			$id=$row['id'];
			$name=$row['Full_Name'];
			$date=$row['Date'];
			$age=$row['Age'];
			$email=$row['Email'];

			$html .= '<tr>';
			$html .= '<td>'.$row['id'].'</td>';
			$html .= '<td>'.$row['Full_Name'].'</td>';
			$html .= '<td>'.$row['Date'].'</td>';
			$html .= '<td>'.$row['Age'].'</td>';
			$html .= '<td>'.$row['Email'].'</td>';
			$html .= '<td>';
			$html .= "<a onclick=\"update($id,'$name',$date,$age,'$email')\"  data-toggle='collapse'><span class='glyphicon glyphicon-pencil'></span></a>";
			$html .= "<a onclick='del($id)'>DELETE</a>";
            $html .= '</td>';
		    $html .= '</tr>';

		}
		echo json_encode(['status'=>'success','html'=>$html]);
	}
	else{
		$html .= '<tr colspan="">';
        $html .= '<td>No Employee Record Found</td>';
		$html .= '</tr>';
		echo json_encode(['status'=>'success','html'=>$html]);

	}
}
function add_record($POST){
	$conn = connection();
	$fname = $_POST['fname'];
	$date = $_POST['date'];
	$age = $_POST['age'];
	$email = $_POST['email'];
	 
	$sql = "INSERT INTO employee(Full_Name,Date,Age,Email) VALUES ('$fname','$date',$age,'$email')";

	$result = mysqli_query($conn,$sql);

	if($result){
		echo json_encode(['status'=>'success','message'=>'Record Inserted!']);
	}
	else
	{
		echo json_encode(['status'=>'error','message'=>'Failed to insert Record']);
	}
	
}

function get_records($POST){
	$conn = connection();
	$id = $_POST['id'];

	$sql = "SELECT * FROM employee WHERE id = ?";
	
	$stmt = mysqli_prepare($conn,$sql);
	if(is_object($stmt)){
		mysqli_stmt_bind_param($stmt,'i',$id);
		mysqli_stmt_bind_result($stmt,$id,$fname,$date,$age,$email);
		mysqli_stmt_execute($stmt);
		mysqli_stmt_store_result($stmt);
		mysqli_stmt_fetch($stmt);

		if(mysqli_stmt_num_rows($stmt)){
		echo json_encode(['status'=>'success','id'=>$id,'fname'=>$fname,'date'=>$date,'age'=>$age,'email'=>$email]);
		}
		else{
			echo json_encode(['status'=>'success','message'=>'Error']);

		}
	}


	echo $fname;



}
/*

*/

?>