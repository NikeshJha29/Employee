<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	 <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Employee Info</title>
        <link href="assets/css/bootstrap.css" rel="stylesheet">
        <link href="assets/css/style.css" rel="stylesheet">
        <script src="assets/js/jquery.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        
</head>
<body>

	<div class="container">
		<a href="#" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#addEmp">
			<span class= "glyphicon glyphicon-plus"></span>
			Add New Employee
</a>
<table class="table table-striped" id="myTable">

	</table>
	<script src="assets/js/script.js"></script>
	</div>

	<!-- Modal -->
<div class="modal fade" id="addEmp" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
  	<form class="form" method="post" action="addEmployee.php">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Add Employee</h4>
      </div>
      <div class="modal-body">
       <div class="form-group">
       	<input type="text" name="fname" placeholder="First Name" class="form-control">
       </div>
        <div class="form-group">
       	<input type="Date" name="date" placeholder="Date of Joining" class="form-control">
       </div>
        <div class="form-group">
       	<input type="text" name="age" placeholder="Age" class="form-control">
       </div>
        <div class="form-group">
       	<input type="text" name="email" placeholder="Email Address" class="form-control">
       </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Add Details</button>
      </div>
    </div>
</form>
  </div>
</div>


	<!-- Modal -->

<div class="modal fade" id="updateEmp" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Modal Header</h4>
        </div>

        <div class="modal-body">
            <input type="text" id='u_id' hidden>

          <div class="form-group">
          <input type="text" id='u_fname' name="fname"  placeholder="First Name" class="form-control fname">
         </div>
          <div class="form-group">
          <input type="Date" id='u_date' name="date"  placeholder="Date of Joining" class="form-control date">
         </div>
          <div class="form-group">
          <input type="text" id='u_age' name="age"  placeholder="Age" class="form-control age">
         </div>
          <div class="form-group">
          <input type="text" id='u_email' name="email"  placeholder="Email Address" class="form-control email">
         </div>


        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          <button type="button" name='update' class="btn btn-primary" onclick="updateDATA()">Update Details</button>
        </div>

      </div>
      
    </div>
  </div>



</body>
</html>